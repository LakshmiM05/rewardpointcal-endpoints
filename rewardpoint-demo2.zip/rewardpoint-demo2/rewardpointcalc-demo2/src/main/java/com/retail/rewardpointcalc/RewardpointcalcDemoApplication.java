package com.retail.rewardpointcalc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardpointcalcDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardpointcalcDemoApplication.class, args);
	}

}
